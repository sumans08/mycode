# Ansible Collection - awesomestudent.myfirstcollection

Documentation for the collection.
